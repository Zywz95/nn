#!/usr/bin/env bash

cd `dirname $0`

. h-manifest.conf

./h9-miner-nock-linux-amd64 -http=${API_PORT}