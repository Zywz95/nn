#!/usr/bin/env bash

mkfile_from_symlink $CUSTOM_CONFIG_FILENAME


conf=""

if [[ ! -z $CUSTOM_TEMPLATE ]]; then
	conf+="apiKey: "
	conf+=$CUSTOM_TEMPLATE
	#while read -r line; do
	#	[[ -z $line ]] && continue
	#	conf+=$line
	#done  <<< "$CUSTOM_TEMPLATE"
fi

conf+="\n"

if [[ ! -z $CUSTOM_URL ]]; then
	conf+="url:\n"
	conf+="  proxy: $CUSTOM_URL\n"
fi
conf+="\n"
conf+="extraParams:\n"
if [[ ! -z $CUSTOM_USER_CONFIG ]]; then
	while read -r line; do
		[[ -z $line ]] && continue
		conf+="  $line\n"
	done  <<< "$CUSTOM_USER_CONFIG"
fi

echo -e "$conf" > $CUSTOM_CONFIG_FILENAME