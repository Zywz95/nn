#!/usr/bin/env bash

. $MINER_DIR/$CUSTOM_MINER/h-manifest.conf

get_cpu_temps () {
	local t_core=`cpu-temp`
	local i=0
	local l_num_cores=$1
	local l_temp=
	for (( i=0; i < ${l_num_cores}; i++ )); do
		l_temp+="$t_core "
	done
  echo ${l_temp[@]} | tr " " "\n" | jq -cs '.'
}

get_cpu_fans () {
	local t_fan=0
	local i=0
	local l_num_cores=$1
	local l_fan=
	for (( i=0; i < ${l_num_cores}; i++ )); do
		l_fan+="$t_fan "
	done
	echo ${l_fan[@]} | tr " " "\n" | jq -cs '.'
}

get_bus_numbers () {
	local i=0
	local l_num_cores=$1
	local l_numbers=
	for (( i=0; i < ${l_num_cores}; i++ )); do
		l_numbers+="null "
	done
	echo ${l_numbers[@]} | tr " " "\n" | jq -cs '.'
}

stats_raw=`curl --connect-timeout 2 --max-time 5 --silent --noproxy '*' http://127.0.0.1:${API_PORT}/summary`
#echo $stats_raw | jq .
if [[ $? -ne 0 || -z $stats_raw ]]; then
	echo -e "${YELLOW}Failed to read $miner from localhost:$MINER_API_PORT${NOCOLOR}"
else
	khs=`echo $stats_raw | jq -r '.total_speed'`
	local ac=$(jq '.acceped' <<< "$stats_raw")
	local rj=$(jq '.rejected' <<< "$stats_raw")
	local num_cores=0
	local cpu_temp=`get_cpu_temps "$num_cores"`
	local cpu_fan=`get_cpu_fans "$num_cores"`
	local bus_numbers=`get_bus_numbers "$num_cores"`
	stats=`echo $stats_raw | jq --arg ac "$ac" --arg rj "$rj" \
                              --argjson temp "$cpu_temp" \
                              --argjson fan "$cpu_fan" \
															--argjson bus_numbers "$bus_numbers" \
					'{hs: .speed, $temp, $fan, ar: [$ac, $rj],
					  uptime: .uptime, algo: .algo, $bus_numbers, ver: .version, hs_units: .hash_units}'`

    #echo $khs.$stats > /hive/custom/$CUSTOM_MINER/stats.log
fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"